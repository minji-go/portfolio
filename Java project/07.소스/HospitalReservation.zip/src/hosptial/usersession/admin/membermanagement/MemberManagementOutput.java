package hosptial.usersession.admin.membermanagement;

public class MemberManagementOutput {

	public static void memberManagementMain() {

	}
}
