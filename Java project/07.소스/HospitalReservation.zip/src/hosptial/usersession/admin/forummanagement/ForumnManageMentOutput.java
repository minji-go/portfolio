package hosptial.usersession.admin.forummanagement;

/**
 * 게시판 관리 화면 출력 클래스입니다.
 * @author joung
 *
 */
public class ForumnManageMentOutput {
	/**
	 * 게시판 관리 메인화면 출력 메서드입니다.
	 */
	public static void forumnManagementMain() {
		System.out.println("=====================================");
		System.out.println("\t[게시판 관리]");
		System.out.println("=====================================");
		System.out.println("0. 뒤로가기");
		System.out.println("1. 게시판목록");
		System.out.println("2. 금지어관리목록");
		System.out.print("번호 : ");
	}

}
