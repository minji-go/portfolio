package hosptial.usersession.admin.forummanagement.forbidden;

/**
 * 금지어를 담을 클래스입니다.
 * @author joung
 *
 */
public class ForbiddenVO {
	String word;
	
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}

}
